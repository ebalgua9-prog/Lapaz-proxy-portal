<?php
require '../includes/auth.php';
require '../config/db.php';
requireRole('admin');

if (isset($_POST['add_subject'])) {
    $pdo->prepare("INSERT INTO subjects (subject_name) VALUES (?)")->execute([$_POST['subject_name']]);
    header("Location: grades.php");
    exit;
}

if (isset($_POST['add_grade'])) {
    $stmt = $pdo->prepare("INSERT INTO grades (student_id, subject_id, quarter, grade) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['student_id'], $_POST['subject_id'], $_POST['quarter'], $_POST['grade']]);
    header("Location: grades.php");
    exit;
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM grades WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: grades.php");
    exit;
}

$students = $pdo->query("
    SELECT s.id, u.full_name, s.lrn FROM students s
    JOIN users u ON s.user_id = u.id ORDER BY u.full_name
")->fetchAll(PDO::FETCH_ASSOC);

$subjects = $pdo->query("SELECT * FROM subjects ORDER BY subject_name")->fetchAll(PDO::FETCH_ASSOC);

$grades = $pdo->query("
    SELECT g.id, u.full_name, sub.subject_name, g.quarter, g.grade
    FROM grades g
    JOIN students s ON g.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON g.subject_id = sub.id
    ORDER BY u.full_name, g.quarter
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Grades - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="brand-mark">La Paz High School<small>Admin Portal</small></div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="students.php">Students</a>
            <a href="grades.php" class="active">Grades</a>
            <a href="announcements.php">Announcements</a>
        </nav>
        <div class="who">
            <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong>
            Administrator
            <a class="logout-link" href="../logout.php">Log out</a>
        </div>
    </aside>

    <main class="main">
        <h1>Grades</h1>
        <p>Add subjects, then record grades per student and quarter.</p>

        <div class="panel">
            <h3 style="margin-top:0;">Add a subject</h3>
            <form method="POST" class="form-inline">
                <input type="text" name="subject_name" placeholder="Subject name (e.g. Mathematics)" required>
                <button type="submit" name="add_subject">Add subject</button>
            </form>
        </div>

        <div class="panel">
            <h3 style="margin-top:0;">Add a grade</h3>
            <form method="POST" class="form-inline">
                <select name="student_id" required>
                    <option value="">Student</option>
                    <?php foreach ($students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['full_name']) ?> (<?= $s['lrn'] ?>)</option>
                    <?php endforeach; ?>
                </select>
                <select name="subject_id" required>
                    <option value="">Subject</option>
                    <?php foreach ($subjects as $sub): ?>
                        <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['subject_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="quarter" required>
                    <option value="1">Quarter 1</option>
                    <option value="2">Quarter 2</option>
                    <option value="3">Quarter 3</option>
                    <option value="4">Quarter 4</option>
                </select>
                <input type="number" step="0.01" min="0" max="100" name="grade" placeholder="Grade" required>
                <button type="submit" name="add_grade">Add grade</button>
            </form>
        </div>

        <h2>All grades</h2>
        <table>
            <tr><th>Student</th><th>Subject</th><th>Quarter</th><th>Grade</th><th></th></tr>
            <?php foreach ($grades as $g): ?>
            <tr>
                <td><?= htmlspecialchars($g['full_name']) ?></td>
                <td><?= htmlspecialchars($g['subject_name']) ?></td>
                <td>Q<?= $g['quarter'] ?></td>
                <td><?= $g['grade'] ?></td>
                <td><a href="?delete=<?= $g['id'] ?>" onclick="return confirm('Delete this grade?')">Delete</a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($grades)): ?>
            <tr><td colspan="5">No grades recorded yet.</td></tr>
            <?php endif; ?>
        </table>
    </main>

</div>
</body>
</html>
