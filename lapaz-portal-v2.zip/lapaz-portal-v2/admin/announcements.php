<?php
require '../includes/auth.php';
require '../config/db.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO announcements (title, content, posted_by) VALUES (?, ?, ?)");
    $stmt->execute([$_POST['title'], $_POST['content'], $_SESSION['user_id']]);
    header("Location: announcements.php");
    exit;
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM announcements WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: announcements.php");
    exit;
}

$announcements = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Announcements - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="brand-mark">La Paz High School<small>Admin Portal</small></div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="students.php">Students</a>
            <a href="grades.php">Grades</a>
            <a href="announcements.php" class="active">Announcements</a>
        </nav>
        <div class="who">
            <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong>
            Administrator
            <a class="logout-link" href="../logout.php">Log out</a>
        </div>
    </aside>

    <main class="main">
        <h1>Announcements</h1>
        <p>Post updates for students to see on their dashboard.</p>

        <div class="panel">
            <form method="POST">
                <input type="text" name="title" placeholder="Title" required>
                <textarea name="content" placeholder="Write the announcement..." required></textarea>
                <button type="submit">Post announcement</button>
            </form>
        </div>

        <?php foreach ($announcements as $a): ?>
            <div class="announcement-card">
                <h3><?= htmlspecialchars($a['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($a['content'])) ?></p>
                <small><?= $a['created_at'] ?></small><br>
                <a class="delete-link" href="?delete=<?= $a['id'] ?>" onclick="return confirm('Delete this announcement?')">Delete</a>
            </div>
        <?php endforeach; ?>
        <?php if (empty($announcements)): ?>
            <p>No announcements posted yet.</p>
        <?php endif; ?>
    </main>

</div>
</body>
</html>
