<?php
require '../includes/auth.php';
require '../config/db.php';
requireRole('admin');

$studentCount = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$announcementCount = $pdo->query("SELECT COUNT(*) FROM announcements")->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="brand-mark">La Paz High School<small>Admin Portal</small></div>
        <nav>
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="students.php">Students</a>
            <a href="grades.php">Grades</a>
            <a href="announcements.php">Announcements</a>
        </nav>
        <div class="who">
            <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong>
            Administrator
            <a class="logout-link" href="../logout.php">Log out</a>
        </div>
    </aside>

    <main class="main">
        <h1>Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></h1>
        <p>A quick look at your school's activity.</p>
        <div class="cards">
            <div class="card">Total students<strong><?= $studentCount ?></strong></div>
            <div class="card">Announcements posted<strong><?= $announcementCount ?></strong></div>
        </div>
    </main>

</div>
</body>
</html>
