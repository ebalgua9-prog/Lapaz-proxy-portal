<?php
require '../includes/auth.php';
require '../config/db.php';
requireRole('admin');

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM students WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: students.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $stmt = $pdo->prepare("UPDATE students SET grade_level=?, section=? WHERE id=?");
    $stmt->execute([$_POST['grade_level'], $_POST['section'], $_POST['id']]);
    header("Location: students.php");
    exit;
}

$students = $pdo->query("
    SELECT s.id, u.full_name, u.email, s.lrn, s.grade_level, s.section
    FROM students s
    JOIN users u ON s.user_id = u.id
    ORDER BY s.grade_level, s.section, u.full_name
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Students - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="brand-mark">La Paz High School<small>Admin Portal</small></div>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="students.php" class="active">Students</a>
            <a href="grades.php">Grades</a>
            <a href="announcements.php">Announcements</a>
        </nav>
        <div class="who">
            <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong>
            Administrator
            <a class="logout-link" href="../logout.php">Log out</a>
        </div>
    </aside>

    <main class="main">
        <h1>Students</h1>
        <p>Update grade level and section, or remove a student record.</p>
        <table>
            <tr><th>LRN</th><th>Name</th><th>Email</th><th>Grade</th><th>Section</th><th>Actions</th></tr>
            <?php foreach ($students as $s): ?>
            <tr>
                <form method="POST">
                    <td><?= htmlspecialchars($s['lrn']) ?></td>
                    <td><?= htmlspecialchars($s['full_name']) ?></td>
                    <td><?= htmlspecialchars($s['email']) ?></td>
                    <td><input type="text" name="grade_level" value="<?= htmlspecialchars($s['grade_level']) ?>" size="3"></td>
                    <td><input type="text" name="section" value="<?= htmlspecialchars($s['section']) ?>" size="6"></td>
                    <td>
                        <input type="hidden" name="id" value="<?= $s['id'] ?>">
                        <button type="submit" style="padding:6px 14px;font-size:0.85rem;">Save</button>
                        <a href="?delete=<?= $s['id'] ?>" onclick="return confirm('Delete this student?')">Delete</a>
                    </td>
                </form>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($students)): ?>
            <tr><td colspan="6">No students registered yet.</td></tr>
            <?php endif; ?>
        </table>
    </main>

</div>
</body>
</html>
