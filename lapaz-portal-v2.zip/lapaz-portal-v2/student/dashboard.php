<?php
require '../includes/auth.php';
require '../config/db.php';
requireRole('student');

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
$stmt->execute([$userId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

$grades = [];
if ($student) {
    $stmt2 = $pdo->prepare("
        SELECT sub.subject_name, g.quarter, g.grade
        FROM grades g
        JOIN subjects sub ON g.subject_id = sub.id
        WHERE g.student_id = ?
        ORDER BY sub.subject_name, g.quarter
    ");
    $stmt2->execute([$student['id']]);
    $grades = $stmt2->fetchAll(PDO::FETCH_ASSOC);
}

$announcements = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <aside class="sidebar">
        <div class="brand-mark">La Paz High School<small>Student Portal</small></div>
        <nav>
            <a href="dashboard.php" class="active">My Dashboard</a>
        </nav>
        <div class="who">
            <strong><?= htmlspecialchars($_SESSION['full_name']) ?></strong>
            <?php if ($student): ?>
                <span>Grade <?= htmlspecialchars($student['grade_level']) ?> - <?= htmlspecialchars($student['section']) ?> · <?= htmlspecialchars($student['lrn']) ?></span>
            <?php endif; ?>
            <a class="logout-link" href="../logout.php">Log out</a>
        </div>
    </aside>

    <main class="main">
        <h1>Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></h1>
        <p>Here's where things stand this quarter.</p>

        <h2>My grades</h2>
        <table>
            <tr><th>Subject</th><th>Quarter</th><th>Grade</th></tr>
            <?php foreach ($grades as $g): ?>
            <tr>
                <td><?= htmlspecialchars($g['subject_name']) ?></td>
                <td>Q<?= $g['quarter'] ?></td>
                <td><?= $g['grade'] ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($grades)): ?>
            <tr><td colspan="3">No grades recorded yet.</td></tr>
            <?php endif; ?>
        </table>

        <h2>Announcements</h2>
        <?php foreach ($announcements as $a): ?>
            <div class="announcement-card">
                <h3><?= htmlspecialchars($a['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($a['content'])) ?></p>
                <small><?= $a['created_at'] ?></small>
            </div>
        <?php endforeach; ?>
        <?php if (empty($announcements)): ?>
            <p>No announcements yet.</p>
        <?php endif; ?>
    </main>

</div>
</body>
</html>
