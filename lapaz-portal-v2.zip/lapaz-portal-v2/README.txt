LA PAZ HIGH SCHOOL PORTAL - LARAGON VERSION (NEW UI)
=======================================================
Same PHP + MySQL system as before, now with the redesigned interface:
split-screen login, sidebar dashboards, serif headings, gold accents.

-----------------------------------------------------------
STEP 1: Put the project in place
-----------------------------------------------------------
1. Open Laragon > click "Start All" (Apache + MySQL should turn green).
2. Menu > Www directory - opens your www folder (usually C:\laragon\www).
3. Copy this WHOLE "lapaz-portal-v2" folder into that Www directory.

-----------------------------------------------------------
STEP 2: Create the database
-----------------------------------------------------------
1. Right-click in Laragon > Database (opens HeidiSQL), or use
   http://localhost/phpmyadmin
2. Open "database.sql" (in this folder), copy ALL of it.
3. Paste into the Query tab, then run it (F9 in HeidiSQL).
   This creates "lapaz_portal" with all its tables + starter subjects.

   NOTE: if you already have an OLD "lapaz_portal" database from the
   previous version, either drop it first (DROP DATABASE lapaz_portal;)
   or skip this step and reuse your existing data - the table structure
   is unchanged, only the design of the pages changed.

-----------------------------------------------------------
STEP 3: Open in VS Code and run
-----------------------------------------------------------
1. VS Code > File > Open Folder > select the copied "lapaz-portal-v2"
   folder inside www.
2. In your browser, go to:
   http://lapaz-portal-v2.test
   (or http://localhost/lapaz-portal-v2 if that address doesn't work)

-----------------------------------------------------------
STEP 4: Create your admin account (skip if reusing old database)
-----------------------------------------------------------
1. Click "Create an account" on the login page, register normally.
2. In HeidiSQL/phpMyAdmin run:
   UPDATE users SET role = 'admin' WHERE email = 'youremail@example.com';
3. Log out and back in - you'll land on the Admin Dashboard.

-----------------------------------------------------------
WHAT CHANGED FROM THE OLD VERSION
-----------------------------------------------------------
- Login/Register: split screen (green brand panel + form)
- Admin & Student pages: persistent sidebar navigation, wider content area
- New color palette (forest green + gold), serif headings
- Same database, same tables, same PHP logic underneath - purely a
  visual upgrade, so nothing about how it works has changed.

FOLDER OVERVIEW
------------------------------------------------
config/db.php           -> database connection settings
includes/auth.php        -> login/session helper functions
admin/                   -> pages only admins can see
student/                 -> pages only students can see
assets/css/style.css     -> all the new styling
database.sql             -> run this once to create your database
login.php / register.php / logout.php / index.php -> entry pages
