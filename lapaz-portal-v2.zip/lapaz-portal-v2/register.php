<?php
require 'config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $pass  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role  = 'student';

    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
    try {
        $stmt->execute([$name, $email, $pass, $role]);
        $userId = $pdo->lastInsertId();

        $lrn = "LP" . str_pad($userId, 6, "0", STR_PAD_LEFT);
        $stmt2 = $pdo->prepare("INSERT INTO students (user_id, lrn, grade_level, section) VALUES (?, ?, ?, ?)");
        $stmt2->execute([$userId, $lrn, $_POST['grade_level'], $_POST['section']]);

        header("Location: login.php?registered=1");
        exit;
    } catch (PDOException $e) {
        $error = "That email is already registered.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register - La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-shell">

    <div class="brand-panel">
        <div class="brand-mark">La Paz High School</div>
        <div>
            <div class="brand-headline">Everything school,<br>in one place.</div>
            <p class="brand-sub">Grades, announcements, and student records — for students, teachers, and staff.</p>
        </div>
        <div class="brand-foot">La Paz High School Portal</div>
    </div>

    <div class="form-panel">
        <div class="form-card">
            <h1>Student registration</h1>
            <p class="lede">Set up your account to view grades and announcements.</p>
            <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
            <form method="POST">
                <input type="text" name="full_name" placeholder="Full name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required minlength="6">
                <select name="grade_level" required>
                    <option value="">Grade level</option>
                    <option value="7">Grade 7</option>
                    <option value="8">Grade 8</option>
                    <option value="9">Grade 9</option>
                    <option value="10">Grade 10</option>
                    <option value="11">Grade 11</option>
                    <option value="12">Grade 12</option>
                </select>
                <input type="text" name="section" placeholder="Section" required>
                <button type="submit">Create account</button>
            </form>
            <p class="switch-line">Already registered? <a href="login.php">Log in</a></p>
        </div>
    </div>

</div>
</body>
</html>
