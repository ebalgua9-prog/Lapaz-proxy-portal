<?php
require 'includes/auth.php';
require 'config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($pass, $user['password'])) {
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role']      = $user['role'];

        if ($user['role'] === 'admin') {
            header("Location: admin/dashboard.php");
        } else {
            header("Location: student/dashboard.php");
        }
        exit;
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>La Paz High School Portal</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&family=Source+Serif+4:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-shell">

    <div class="brand-panel">
        <div class="brand-mark">La Paz High School</div>
        <div>
            <div class="brand-headline">Everything school,<br>in one place.</div>
            <p class="brand-sub">Grades, announcements, and student records — for students, teachers, and staff.</p>
        </div>
        <div class="brand-foot">La Paz High School Portal</div>
    </div>

    <div class="form-panel">
        <div class="form-card">
            <h1>Welcome back</h1>
            <p class="lede">Log in to see your grades and school announcements.</p>
            <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
            <?php if (isset($_GET['registered'])): ?><p class="success">Registered successfully! Please log in.</p><?php endif; ?>
            <form method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Log in</button>
            </form>
            <p class="switch-line">New here? <a href="register.php">Create an account</a></p>
        </div>
    </div>

</div>
</body>
</html>
